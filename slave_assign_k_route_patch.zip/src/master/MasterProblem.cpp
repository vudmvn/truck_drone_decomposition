#include "bbcp/master/MasterProblem.h"

#include <iostream>
#include <stdexcept>

#include "bbcp/heuristics/InitialSolution.h"
#include "bbcp/heuristics/LocalSearch.h"
#include "bbcp/io/ResultWriter.h"
#include "bbcp/master/MasterCallback.h"
#include "bbcp/master/MasterModelBuilder.h"
#include "bbcp/slave/SlaveSolverFactory.h"

#include "gurobi_c++.h"

namespace bbcp
{

    MasterProblem::MasterProblem(const Instance &inst, const MasterOptions &options)
        : inst_(inst), options_(options) {}

    FullSolution MasterProblem::Solve()
    {
        if (options_.verbose)
        {
            std::cout << "[SOLVE] exact decomposition master"
                      << ", instance=" << inst_.name
                      << ", n=" << inst_.n
                      << ", drones=" << inst_.n_drones
                      << ", slave=" << SlaveSolverTypeName(options_.slave_solver)
                      << ", assignment_mode=" << MasterAssignmentModeName(options_.assignment_mode)
                      << "\n";
        }

        // This is only a valid initial incumbent / upper bound.
        // It is not a fallback algorithm and is not returned unless the exact
        // decomposition master cannot improve it.
        FullSolution incumbent = InitialSolution::GreedyAllTruck(inst_);

        if (options_.verbose)
        {
            std::cout << "[INIT] all-truck valid UB=" << incumbent.objective << "\n";
        }

        try
        {
            GRBEnv env(true);
            env.set(GRB_IntParam_OutputFlag, options_.verbose ? 1 : 0);
            env.start();

            GRBModel model(env);
            model.set(GRB_StringAttr_ModelName, "truck_drone_decomposition_master");

            model.set(GRB_IntParam_LazyConstraints, 1);
            model.set(GRB_IntParam_PreCrush, 1);

            // The master relaxation is the bottleneck for proving lower bounds.
            // These settings prioritize bound improvement and allow more aggressive
            // generic cutting planes in addition to our MIPNODE user cuts.
            model.set(GRB_IntParam_MIPFocus, 3);
            model.set(GRB_IntParam_Cuts, 2);

            if (options_.time_limit_seconds > 0.0)
            {
                model.set(GRB_DoubleParam_TimeLimit, options_.time_limit_seconds);
            }

            if (options_.mip_gap > 0.0)
            {
                model.set(GRB_DoubleParam_MIPGap, options_.mip_gap);
            }

            MasterModelBuilder builder(inst_, options_);
            MasterModelData data = builder.BuildGurobiModel(model, incumbent.objective);

            // Explicit mode calls the slave per anonymous drone k.
            // Slave-assign mode calls the CP-SAT slave once with the full set S={i:y_i=1};
            // the slave then creates exactly K routes and assigns customers to drones.
            auto slave = CreateSlaveSolver(inst_, options_.slave_solver);

            if (options_.verbose)
            {
                std::cout << "[SLAVE] requested=" << SlaveSolverTypeName(options_.slave_solver)
                          << ", actual=" << slave->Name() << "\n";
            }

            MasterCallback cb(inst_, options_, data, *slave, incumbent);
            model.setCallback(&cb);

            model.optimize();

            FullSolution best = cb.BestSolution();

            if (options_.verbose)
            {
                std::cout << "\n=== Exact decomposition finished ===\n";
                std::cout << "Best valid UB: " << cb.BestValidUB() << "\n";
            }

            // Optional improvement of a solver-verified incumbent only.
            // This is not used as a fallback replacement for the master.
            if (best.feasible && options_.local_search_options.enabled)
            {
                LocalSearch ls(inst_, options_.local_search_options, *slave);
                FullSolution improved;
                if (ls.Improve(best, improved) && improved.objective < best.objective)
                {
                    best = improved;
                    if (options_.verbose)
                    {
                        std::cout << "[LS NEW BEST] objective=" << best.objective << "\n";
                    }
                }
            }

            ResultWriter::WriteCSV(options_.result_file, inst_, options_, best);
            ResultWriter::WriteSolutionText("results/solutions/solution.txt", best);

            return best;
        }
        catch (const GRBException &e)
        {
            std::cerr << "[GUROBI ERROR] " << e.getMessage() << "\n";
            throw;
        }
    }

} // namespace bbcp
