#pragma once

#include <vector>

#include "bbcp/core/Instance.h"
#include "bbcp/core/Options.h"
#include "bbcp/core/Solution.h"
#include "bbcp/master/MasterModelBuilder.h"
#include "bbcp/slave/ISlaveSolver.h"

#include "gurobi_c++.h"

namespace bbcp
{

    class MasterCallback : public GRBCallback
    {
    public:
        MasterCallback(
            const Instance &inst,
            const MasterOptions &options,
            const MasterModelData &data,
            const ISlaveSolver &slave,
            const FullSolution &initial_incumbent);

        const FullSolution &BestSolution() const;
        double BestValidUB() const;

    protected:
        void callback() override;

    private:
        const Instance &inst_;
        MasterOptions options_;
        const MasterModelData &data_;
        const ISlaveSolver &slave_;

        FullSolution best_solution_;
        double best_valid_ub_ = GRB_INFINITY;

        void HandleIntegerSolution();
        void HandleIntegerSolutionExplicit();
        void HandleIntegerSolutionSlaveAssign();

        bool SeparateIntegerTruckSubtourCuts(
            const std::vector<int> &tbar,
            const std::vector<std::vector<int>> &xbar);

        std::vector<std::vector<Node>> FindTruckSubtours(
            const std::vector<int> &tbar,
            const std::vector<std::vector<int>> &xbar) const;

        void AddTruckSubtourEliminationCut(
            const std::vector<Node> &S);

        std::vector<Node> DecodeTruckRoute(
            const std::vector<std::vector<int>> &xbar) const;

        double ComputeTruckValue(
            const std::vector<std::vector<int>> &xbar) const;

        void AddDroneSubsetLowerBoundCut(
            int drone_id,
            const std::vector<Node> &S,
            double rhs);

        void AddBroadcastDroneSubsetLowerBoundCut(
            const std::vector<Node> &S,
            double rhs);

        void AddGlobalDroneSubsetLowerBoundCut(
            const std::vector<Node> &S,
            double rhs);

        void AddDroneNoGoodCut(
            int drone_id,
            const std::vector<Node> &S);

        void AddBroadcastDroneNoGoodCut(
            const std::vector<Node> &S);

        void AddGlobalDroneNoGoodCut(
            const std::vector<Node> &S);

        std::string NodeListString(const std::vector<Node> &nodes) const;

        void PrintSlaveCall(
            int drone_id,
            const std::vector<Node> &S,
            int64_t cutoff) const;

        void PrintSlaveResult(
            int drone_id,
            const std::vector<Node> &S,
            int64_t cutoff,
            const SlaveResult &result) const;

        void SubmitRepairedIncumbent(
            const std::vector<int> &tbar,
            const std::vector<std::vector<int>> &abar,
            const std::vector<std::vector<int>> &xbar,
            const std::vector<double> &drone_values,
            const std::vector<int> &swap_counts,
            double truck_value,
            double drone_value,
            double submitted_z);

        bool TryAccept(
            const std::vector<int> &tbar,
            const std::vector<std::vector<int>> &abar,
            const std::vector<std::vector<int>> &xbar,
            const std::vector<std::vector<Node>> &per_drone_customers,
            const DroneSchedule &drone_schedule,
            const std::vector<double> &drone_values,
            const std::vector<int> &swap_counts,
            double truck_value,
            double drone_value,
            double accepted_z,
            double submitted_z);

        void HandleMIPNode();

        bool IsTruckArcAllowed(Node i, Node j) const;

        void SeparateFractionalTruckConnectivityCuts(
            const std::vector<double> &trel,
            const std::vector<std::vector<double>> &xrel,
            int &cuts_added,
            int max_cuts);

        void SeparateFractionalDroneCoverCuts(
            const std::vector<std::vector<double>> &arel,
            const std::vector<double> &qrel,
            const std::vector<double> &zKrel,
            int &cuts_added,
            int max_cuts);

        bool TryAddTruckConnectivityCutsForSet(
            const std::vector<Node> &S,
            const std::vector<double> &trel,
            const std::vector<std::vector<double>> &xrel,
            int &cuts_added,
            int max_cuts);

        bool TryAddDroneCoverCutsForSet(
            int drone_id,
            const std::vector<Node> &H,
            const std::vector<std::vector<double>> &arel,
            double qrel,
            double zKrel,
            int &cuts_added,
            int max_cuts);
    };

} // namespace bbcp
