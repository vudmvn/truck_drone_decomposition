#pragma once

#include <cstdint>
#include <string>

namespace bbcp
{

    enum class SlaveSolverType
    {
        CP,
        MILP,
        SingleDroneOrdering
    };

    enum class MasterSubtourMode
    {
        // Miller--Tucker--Zemlin ordering constraints are added directly to the master.
        MTZ,

        // Subtour-elimination constraints are separated lazily at integer solutions.
        // Backward-compatible names: cut, lazy, lazycut.
        SEC,
        LazyCut = SEC
    };

    enum class BranchingStrategy
    {
        Default,
        AssignmentFirst,
        CPAware,
        AmbiguityFirst,
        DroneBenefit,
        Hybrid
    };

    struct SlaveOptions
    {
        double time_limit_seconds = 5.0;
        double phase2_time_limit_seconds = 10.0;

        bool log_search = false;
        bool stop_after_first_solution = false;

        int64_t makespan_cutoff = -1;
        bool add_cutoff_valid_inequalities = true;
    };

    struct LocalSearchOptions
    {
        bool enabled = true;
        int max_rounds = 100;
        int max_moves_per_round = 100000;
        double time_limit_seconds = 5.0;
    };

    struct MasterOptions
    {
        std::string instance_name;
        std::string result_file = "results/csv/result.csv";

        double time_limit_seconds = 3600.0;
        double mip_gap = 0.0;
        double big_m = 1e7;

        bool verbose = true;
        bool cut_verbose = false;

        MasterSubtourMode subtour_mode = MasterSubtourMode::MTZ;
        BranchingStrategy branching_strategy = BranchingStrategy::Hybrid;
        SlaveSolverType slave_solver = SlaveSolverType::CP;

        bool enable_mipnode_cuts = false;

        // Enable fractional truck subtour-elimination user cuts at MIPNODE.
        // This is intentionally configured in main.cpp, not parsed from argv,
        // so experiments can switch it on/off by changing one line.
        bool enable_mipnode_truck_sec_cuts = false;

        bool use_branching_var_hints = true;

        SlaveOptions slave_options;
        LocalSearchOptions local_search_options;
    };

    SlaveSolverType ParseSlaveSolverType(const std::string &raw);
    std::string SlaveSolverTypeName(SlaveSolverType type);

    MasterSubtourMode ParseMasterSubtourMode(const std::string &raw);
    std::string MasterSubtourModeName(MasterSubtourMode mode);

    BranchingStrategy ParseBranchingStrategy(const std::string &raw);
    std::string BranchingStrategyName(BranchingStrategy strategy);

    // Backward-compatible names used by the old main.cpp.
    inline BranchingStrategy ParseMasterBranchingStrategy(const std::string &raw)
    {
        return ParseBranchingStrategy(raw);
    }

    inline std::string MasterBranchingStrategyName(BranchingStrategy strategy)
    {
        return BranchingStrategyName(strategy);
    }

} // namespace bbcp
