#include "bbcp/master/MasterCallback.h"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>

#include "bbcp/master/MasterCuts.h"

namespace bbcp
{

    MasterCallback::MasterCallback(
        const Instance &inst,
        const MasterOptions &options,
        const MasterModelData &data,
        const ISlaveSolver &slave,
        const FullSolution &initial_incumbent) : inst_(inst),
                                                 options_(options),
                                                 data_(data),
                                                 slave_(slave),
                                                 best_solution_(initial_incumbent),
                                                 best_valid_ub_(initial_incumbent.feasible ? initial_incumbent.objective : GRB_INFINITY) {}

    const FullSolution &MasterCallback::BestSolution() const
    {
        return best_solution_;
    }

    double MasterCallback::BestValidUB() const
    {
        return best_valid_ub_;
    }

    void MasterCallback::callback()
    {
        try
        {
            if (where == GRB_CB_MIPSOL)
            {
                HandleIntegerSolution();
                return;
            }

            if (where == GRB_CB_MIPNODE)
            {
                HandleMIPNode();
                return;
            }
        }
        catch (const GRBException &e)
        {
            std::cerr << "[CALLBACK-GUROBI-ERROR] " << e.getMessage() << "\n";
        }
        catch (const std::exception &e)
        {
            std::cerr << "[CALLBACK-ERROR] " << e.what() << "\n";
        }
    }

    std::vector<Node> MasterCallback::DecodeTruckRoute(
        const std::vector<std::vector<int>> &xbar) const
    {
        const int N = inst_.NumNodes();

        std::vector<Node> route;
        std::vector<int> seen(N, 0);

        Node cur = inst_.start_depot;
        route.push_back(cur);
        seen[cur] = 1;

        while (cur != inst_.end_depot)
        {
            Node nxt = -1;

            for (int j = 0; j < N; ++j)
            {
                if (xbar[cur][j] == 1)
                {
                    nxt = j;
                    break;
                }
            }

            if (nxt == -1)
            {
                return {};
            }

            if (nxt != inst_.end_depot && seen[nxt])
            {
                return {};
            }

            route.push_back(nxt);
            seen[nxt] = 1;
            cur = nxt;
        }

        return route;
    }

    double MasterCallback::ComputeTruckValue(
        const std::vector<std::vector<int>> &xbar) const
    {
        const int N = inst_.NumNodes();
        double value = 0.0;

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if (xbar[i][j] == 1)
                {
                    value += static_cast<double>(inst_.truck_time[i][j]);
                }
            }
        }

        return value;
    }

    void MasterCallback::AddDroneSubsetLowerBoundCut(
        int drone_id,
        const std::vector<Node> &S,
        double rhs)
    {
        if (S.empty() || rhs <= 0.0)
        {
            return;
        }

        const double local_m = MasterCuts::LocalBigM(rhs);

        GRBLinExpr missing = 0.0;
        for (Node i : S)
        {
            missing += (1.0 - data_.a[i][drone_id]);
        }

        GRBLinExpr lhs = data_.zK[drone_id] + local_m * missing;
        addLazy(lhs >= rhs);

        if (options_.cut_verbose)
        {
            std::cout << "[CUT] subset-LB drone=" << drone_id
                      << ", size=" << S.size()
                      << ", rhs=" << rhs
                      << ", M=" << local_m << "\n";
        }
    }

    void MasterCallback::AddBroadcastDroneSubsetLowerBoundCut(
        const std::vector<Node> &S,
        double rhs)
    {
        for (int ell = 0; ell < inst_.n_drones; ++ell)
        {
            AddDroneSubsetLowerBoundCut(ell, S, rhs);
        }
    }

    void MasterCallback::AddDroneNoGoodCut(
        int drone_id,
        const std::vector<Node> &S)
    {
        if (S.empty())
        {
            return;
        }

        GRBLinExpr lhs = 0.0;
        for (Node i : S)
        {
            lhs += data_.a[i][drone_id];
        }

        addLazy(lhs <= static_cast<int>(S.size()) - 1);

        if (options_.cut_verbose)
        {
            std::cout << "[CUT] drone no-good drone=" << drone_id
                      << ", size=" << S.size() << "\n";
        }
    }

    void MasterCallback::AddBroadcastDroneNoGoodCut(
        const std::vector<Node> &S)
    {
        for (int ell = 0; ell < inst_.n_drones; ++ell)
        {
            AddDroneNoGoodCut(ell, S);
        }
    }

    std::string MasterCallback::NodeListString(const std::vector<Node> &nodes) const
    {
        std::ostringstream oss;
        oss << "{";
        for (size_t p = 0; p < nodes.size(); ++p)
        {
            if (p > 0)
                oss << ",";
            oss << nodes[p];
        }
        oss << "}";
        return oss.str();
    }

    void MasterCallback::PrintSlaveCall(
        int drone_id,
        const std::vector<Node> &S,
        int64_t cutoff) const
    {
        if (!options_.verbose)
        {
            return;
        }

        std::cout << "  [SLAVE-CALL] drone=" << drone_id
                  << ", |S|=" << S.size()
                  << ", cutoff=";

        if (cutoff >= 0)
        {
            std::cout << cutoff;
        }
        else
        {
            std::cout << "none";
        }

        std::cout << ", S=" << NodeListString(S) << "\n";
    }

    void MasterCallback::PrintSlaveResult(
        int drone_id,
        const std::vector<Node> &S,
        int64_t cutoff,
        const SlaveResult &result) const
    {
        if (!options_.verbose)
        {
            return;
        }

        std::cout << "  [SLAVE-RESULT] drone=" << drone_id
                  << ", |S|=" << S.size()
                  << ", cutoff=";

        if (cutoff >= 0)
        {
            std::cout << cutoff;
        }
        else
        {
            std::cout << "none";
        }

        std::cout << ", feasible=" << (result.feasible ? 1 : 0)
                  << ", optimal=" << (result.optimal ? 1 : 0)
                  << ", proven_infeasible=" << (result.proven_infeasible ? 1 : 0)
                  << ", unknown=" << (result.unknown ? 1 : 0);

        if (result.feasible)
        {
            std::cout << ", obj=" << result.objective;
        }
        else
        {
            std::cout << ", obj=N/A";
        }

        if (result.lower_bound_valid)
        {
            std::cout << ", lb=" << result.lower_bound;
        }
        else
        {
            std::cout << ", lb=N/A";
        }

        std::cout << ", wall_time=" << result.wall_time
                  << ", S=" << NodeListString(S)
                  << "\n";

        if (result.feasible && !result.chains.empty())
        {
            const std::vector<Node> &chain = result.chains.front();
            const std::vector<int> *swaps = nullptr;

            if (!result.swap_before.empty())
            {
                swaps = &result.swap_before.front();
            }

            std::cout << "                 chain: ";
            if (chain.empty())
            {
                std::cout << "(empty)";
            }

            for (size_t p = 0; p < chain.size(); ++p)
            {
                if (p > 0)
                {
                    std::cout << " -> ";
                }

                const bool has_swap =
                    (swaps != nullptr && p < swaps->size() && (*swaps)[p] != 0);

                if (has_swap)
                {
                    std::cout << "[SWAP] ";
                }

                std::cout << chain[p];
            }

            std::cout << "\n";

            if (swaps != nullptr)
            {
                std::cout << "                 swaps_before: ";
                bool any = false;

                for (size_t p = 0; p < chain.size() && p < swaps->size(); ++p)
                {
                    if ((*swaps)[p] != 0)
                    {
                        if (any)
                        {
                            std::cout << ",";
                        }
                        std::cout << chain[p];
                        any = true;
                    }
                }

                if (!any)
                {
                    std::cout << "none";
                }

                std::cout << "\n";
            }
        }
    }

    void MasterCallback::SubmitRepairedIncumbent(
        const std::vector<int> &tbar,
        const std::vector<std::vector<int>> &abar,
        const std::vector<std::vector<int>> &xbar,
        const std::vector<double> &drone_values,
        const std::vector<int> &swap_counts,
        double truck_value,
        double drone_value,
        double submitted_z)
    {
        std::vector<GRBVar> vars;
        std::vector<double> vals;

        const int N = inst_.NumNodes();

        std::vector<int> ybar(N, 0);

        for (Node i = 1; i <= inst_.n; ++i)
        {
            for (int k = 0; k < inst_.n_drones; ++k)
            {
                if (abar[i][k] == 1)
                {
                    ybar[i] = 1;
                }
            }
        }

        for (Node i = 1; i <= inst_.n; ++i)
        {
            vars.push_back(data_.t[i]);
            vals.push_back(static_cast<double>(tbar[i]));

            vars.push_back(data_.y[i]);
            vals.push_back(static_cast<double>(ybar[i]));

            for (int k = 0; k < inst_.n_drones; ++k)
            {
                vars.push_back(data_.a[i][k]);
                vals.push_back(static_cast<double>(abar[i][k]));
            }
        }

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if (i == j)
                    continue;
                if (i == inst_.end_depot)
                    continue;
                if (j == inst_.start_depot)
                    continue;

                vars.push_back(data_.x[i][j]);
                vals.push_back(static_cast<double>(xbar[i][j]));
            }
        }

        for (int k = 0; k < inst_.n_drones; ++k)
        {
            vars.push_back(data_.zK[k]);
            vals.push_back(k < static_cast<int>(drone_values.size()) ? drone_values[k] : 0.0);

            vars.push_back(data_.q[k]);
            vals.push_back(k < static_cast<int>(swap_counts.size()) ? swap_counts[k] : 0.0);
        }

        vars.push_back(data_.zT);
        vals.push_back(truck_value);

        vars.push_back(data_.zD);
        vals.push_back(drone_value);

        vars.push_back(data_.z);
        vals.push_back(submitted_z);

        setSolution(vars.data(), vals.data(), static_cast<int>(vars.size()));
    }

    bool MasterCallback::TryAccept(
        const std::vector<int> &tbar,
        const std::vector<std::vector<int>> &abar,
        const std::vector<std::vector<int>> &xbar,
        const std::vector<std::vector<Node>> &per_drone_customers,
        const DroneSchedule &drone_schedule,
        const std::vector<double> &drone_values,
        const std::vector<int> &swap_counts,
        double truck_value,
        double drone_value,
        double accepted_z,
        double submitted_z)
    {
        if (accepted_z + 1e-6 >= best_valid_ub_)
        {
            return false;
        }

        // Update the valid original-problem UB by the true checked value.
        // Submit to Gurobi using submitted_z = max(master_z, accepted_z).
        best_valid_ub_ = accepted_z;

        FullSolution sol;
        sol.feasible = true;
        sol.objective = accepted_z;
        sol.truck_value = truck_value;
        sol.drone_value = drone_value;
        sol.truck_route = DecodeTruckRoute(xbar);
        sol.per_drone_customers = per_drone_customers;
        sol.drone_schedule = drone_schedule;

        for (Node i = 1; i <= inst_.n; ++i)
        {
            if (tbar[i] == 1)
            {
                sol.truck_customers.push_back(i);
            }
            else
            {
                sol.drone_customers.push_back(i);
            }
        }

        best_solution_ = sol;

        SubmitRepairedIncumbent(
            tbar,
            abar,
            xbar,
            drone_values,
            swap_counts,
            truck_value,
            drone_value,
            submitted_z);

        if (options_.verbose)
        {
            std::cout << "\n[NEW BEST] accepted_z=" << accepted_z
                      << ", submitted_master_z=" << submitted_z
                      << ", truck=" << truck_value
                      << ", drone=" << drone_value
                      << "\n";
        }

        return true;
    }

    bool MasterCallback::IsTruckArcAllowed(Node i, Node j) const
    {
        if (i == j)
            return false;
        if (i == inst_.end_depot)
            return false;
        if (j == inst_.start_depot)
            return false;
        return true;
    }

    std::vector<std::vector<Node>> MasterCallback::FindTruckSubtours(
        const std::vector<int> &tbar,
        const std::vector<std::vector<int>> &xbar) const
    {
        const int N = inst_.NumNodes();

        // First follow the unique truck path starting at the start depot.
        // Any selected truck customer not reached by this path belongs to a
        // disconnected truck component, which must be cut in SEC mode.
        std::vector<int> reached(N, 0);
        Node cur = inst_.start_depot;

        for (int step = 0; step <= N + 1; ++step)
        {
            if (cur < 0 || cur >= N)
            {
                break;
            }

            if (reached[cur])
            {
                break;
            }

            reached[cur] = 1;

            if (cur == inst_.end_depot)
            {
                break;
            }

            Node nxt = -1;
            for (int j = 0; j < N; ++j)
            {
                if (xbar[cur][j] == 1)
                {
                    nxt = j;
                    break;
                }
            }

            if (nxt == -1)
            {
                break;
            }

            cur = nxt;
        }

        std::vector<std::vector<Node>> subtours;
        std::vector<int> visited(N, 0);

        for (Node root = 1; root <= inst_.n; ++root)
        {
            if (tbar[root] == 0 || reached[root] || visited[root])
            {
                continue;
            }

            std::vector<Node> stack = {root};
            std::vector<Node> comp;
            visited[root] = 1;

            while (!stack.empty())
            {
                Node v = stack.back();
                stack.pop_back();
                comp.push_back(v);

                for (Node u = 1; u <= inst_.n; ++u)
                {
                    if (tbar[u] == 0 || reached[u] || visited[u])
                    {
                        continue;
                    }

                    // Use the undirected support of the integer truck arcs to
                    // collect the entire disconnected component.
                    if (xbar[v][u] == 1 || xbar[u][v] == 1)
                    {
                        visited[u] = 1;
                        stack.push_back(u);
                    }
                }
            }

            if (comp.size() <= 1)
            {
                continue;
            }

            int internal_arcs = 0;
            for (Node i : comp)
            {
                for (Node j : comp)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    if (xbar[i][j] == 1)
                    {
                        ++internal_arcs;
                    }
                }
            }

            // For a pure subtour, the number of internal directed arcs is |S|.
            // The SEC cut sum_{i,j in S} x_ij <= |S|-1 removes it.
            if (internal_arcs >= static_cast<int>(comp.size()))
            {
                std::sort(comp.begin(), comp.end());
                subtours.push_back(comp);
            }
        }

        return subtours;
    }

    void MasterCallback::AddTruckSubtourEliminationCut(
        const std::vector<Node> &S)
    {
        if (S.size() <= 1)
        {
            return;
        }

        GRBLinExpr lhs = 0.0;

        for (Node i : S)
        {
            for (Node j : S)
            {
                if (i == j)
                {
                    continue;
                }
                if (!IsTruckArcAllowed(i, j))
                {
                    continue;
                }
                lhs += data_.x[i][j];
            }
        }

        addLazy(lhs <= static_cast<int>(S.size()) - 1);

        if (options_.cut_verbose || options_.verbose)
        {
            std::cout << "[LAZY-SEC] truck subtour cut"
                      << ", |S|=" << S.size()
                      << ", S=" << NodeListString(S)
                      << "\n";
        }
    }

    bool MasterCallback::SeparateIntegerTruckSubtourCuts(
        const std::vector<int> &tbar,
        const std::vector<std::vector<int>> &xbar)
    {
        if (options_.subtour_mode != MasterSubtourMode::SEC)
        {
            return false;
        }

        const std::vector<std::vector<Node>> subtours = FindTruckSubtours(tbar, xbar);

        for (const std::vector<Node> &S : subtours)
        {
            AddTruckSubtourEliminationCut(S);
        }

        return !subtours.empty();
    }

    void MasterCallback::HandleMIPNode()
    {
        const int node_status = getIntInfo(GRB_CB_MIPNODE_STATUS);

        if (node_status != GRB_OPTIMAL)
        {
            return;
        }

        const int N = inst_.NumNodes();
        const int K = inst_.n_drones;

        std::vector<double> trel(N, 0.0);
        std::vector<std::vector<double>> xrel(N, std::vector<double>(N, 0.0));
        std::vector<std::vector<double>> arel(N, std::vector<double>(K, 0.0));
        std::vector<double> qrel(K, 0.0);
        std::vector<double> zKrel(K, 0.0);

        for (Node i = 1; i <= inst_.n; ++i)
        {
            trel[i] = getNodeRel(data_.t[i]);

            for (int k = 0; k < K; ++k)
            {
                arel[i][k] = getNodeRel(data_.a[i][k]);
            }
        }

        for (int k = 0; k < K; ++k)
        {
            qrel[k] = getNodeRel(data_.q[k]);
            zKrel[k] = getNodeRel(data_.zK[k]);
        }

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if (!IsTruckArcAllowed(i, j))
                    continue;
                xrel[i][j] = getNodeRel(data_.x[i][j]);
            }
        }

        int cuts_added = 0;
        const int max_cuts = 80;

        // Optional fractional subtour-elimination user cuts for the truck path.
        // This is separated at MIPNODE with addCut(), while integer truck
        // subtours are still handled at MIPSOL with addLazy().
        if (options_.enable_mipnode_truck_sec_cuts &&
            options_.subtour_mode == MasterSubtourMode::SEC)
        {
            SeparateFractionalTruckSECCuts(trel, xrel, cuts_added, max_cuts);
        }

        if (cuts_added < max_cuts)
        {
            SeparateFractionalTruckConnectivityCuts(trel, xrel, cuts_added, max_cuts);
        }

        if (cuts_added < max_cuts)
        {
            SeparateFractionalDroneCoverCuts(arel, qrel, zKrel, cuts_added, max_cuts);
        }

        if (options_.cut_verbose && cuts_added > 0)
        {
            std::cout << "[USERCUT-MIPNODE] cuts_added=" << cuts_added << "\n";
        }
    }

    void MasterCallback::SeparateFractionalTruckSECCuts(
        const std::vector<double> &trel,
        const std::vector<std::vector<double>> &xrel,
        int &cuts_added,
        int max_cuts)
    {
        const int N = inst_.NumNodes();

        // Use several thresholds to obtain candidate components from the
        // fractional truck support graph. High thresholds catch clear subtours;
        // low thresholds catch weaker fractional components.
        const std::vector<double> thresholds = {0.50, 0.25, 0.10, 0.05, 1e-6};

        std::set<std::vector<Node>> tried_sets;

        for (double threshold : thresholds)
        {
            if (cuts_added >= max_cuts)
            {
                return;
            }

            std::vector<std::vector<int>> adj(N);

            for (int i = 0; i < N; ++i)
            {
                for (int j = 0; j < N; ++j)
                {
                    if (!IsTruckArcAllowed(i, j))
                    {
                        continue;
                    }

                    // Undirected support graph for component detection.
                    if (xrel[i][j] > threshold || xrel[j][i] > threshold)
                    {
                        adj[i].push_back(j);
                        adj[j].push_back(i);
                    }
                }
            }

            std::vector<int> visited(N, 0);

            for (Node root = 1; root <= inst_.n; ++root)
            {
                if (visited[root])
                {
                    continue;
                }

                std::vector<int> stack = {root};
                std::vector<Node> comp;
                visited[root] = 1;

                bool contains_start = false;
                bool contains_end = false;

                while (!stack.empty())
                {
                    const int v = stack.back();
                    stack.pop_back();

                    if (v == inst_.start_depot)
                    {
                        contains_start = true;
                    }
                    if (v == inst_.end_depot)
                    {
                        contains_end = true;
                    }

                    if (v >= 1 && v <= inst_.n && trel[v] > 1e-9)
                    {
                        comp.push_back(v);
                    }

                    for (int nxt : adj[v])
                    {
                        if (visited[nxt])
                        {
                            continue;
                        }
                        visited[nxt] = 1;
                        stack.push_back(nxt);
                    }
                }

                // Only components disconnected from both depot nodes can define
                // a truck subtour candidate.
                if (contains_start || contains_end)
                {
                    continue;
                }

                if (comp.size() <= 1)
                {
                    continue;
                }

                std::sort(comp.begin(), comp.end());

                if (tried_sets.count(comp) != 0)
                {
                    continue;
                }
                tried_sets.insert(comp);

                TryAddTruckSECCutForSet(comp, trel, xrel, cuts_added, max_cuts);

                if (cuts_added >= max_cuts)
                {
                    return;
                }
            }
        }
    }

    bool MasterCallback::TryAddTruckSECCutForSet(
        const std::vector<Node> &S,
        const std::vector<double> &trel,
        const std::vector<std::vector<double>> &xrel,
        int &cuts_added,
        int max_cuts)
    {
        if (S.size() <= 1 || cuts_added >= max_cuts)
        {
            return false;
        }

        const double eps = 1e-6;

        // Optional-customer SEC:
        //   sum_{i,j in S, i != j} x_ij <= sum_{i in S} t_i - t_h.
        // h is chosen as the most truck-selected node in the current relaxation
        // to make the separated inequality as tight as possible.
        Node h = S.front();
        double sum_t = 0.0;

        for (Node i : S)
        {
            sum_t += trel[i];
            if (trel[i] > trel[h])
            {
                h = i;
            }
        }

        if (trel[h] <= eps)
        {
            return false;
        }

        double lhs_value = 0.0;

        for (Node i : S)
        {
            for (Node j : S)
            {
                if (i == j)
                {
                    continue;
                }
                if (!IsTruckArcAllowed(i, j))
                {
                    continue;
                }
                lhs_value += xrel[i][j];
            }
        }

        const double rhs_value = sum_t - trel[h];

        if (lhs_value <= rhs_value + 1e-6)
        {
            return false;
        }

        GRBLinExpr lhs = 0.0;
        GRBLinExpr rhs = 0.0;

        for (Node i : S)
        {
            rhs += data_.t[i];

            for (Node j : S)
            {
                if (i == j)
                {
                    continue;
                }
                if (!IsTruckArcAllowed(i, j))
                {
                    continue;
                }
                lhs += data_.x[i][j];
            }
        }

        rhs -= data_.t[h];

        addCut(lhs <= rhs);
        ++cuts_added;

        if (options_.cut_verbose)
        {
            std::cout << "[USERCUT-MIPNODE-SEC] truck optional SEC"
                      << ", |S|=" << S.size()
                      << ", h=" << h
                      << ", lhs=" << lhs_value
                      << ", rhs=" << rhs_value
                      << ", S=" << NodeListString(S)
                      << "\n";
        }

        return true;
    }

    void MasterCallback::SeparateFractionalTruckConnectivityCuts(
        const std::vector<double> &trel,
        const std::vector<std::vector<double>> &xrel,
        int &cuts_added,
        int max_cuts)
    {
        const int N = inst_.NumNodes();
        const double eps = 1e-6;

        // Build an undirected support graph from positive truck arcs.
        std::vector<std::vector<int>> adj(N);

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if (!IsTruckArcAllowed(i, j))
                    continue;

                if (xrel[i][j] > eps)
                {
                    adj[i].push_back(j);
                    adj[j].push_back(i);
                }
            }
        }

        std::vector<int> visited(N, 0);

        for (int root = 0; root < N; ++root)
        {
            if (visited[root])
                continue;

            std::vector<int> stack = {root};
            std::vector<int> comp;
            visited[root] = 1;

            bool contains_start = false;
            bool contains_end = false;

            while (!stack.empty())
            {
                int v = stack.back();
                stack.pop_back();

                comp.push_back(v);

                if (v == inst_.start_depot)
                    contains_start = true;
                if (v == inst_.end_depot)
                    contains_end = true;

                for (int nxt : adj[v])
                {
                    if (visited[nxt])
                        continue;
                    visited[nxt] = 1;
                    stack.push_back(nxt);
                }
            }

            // Components containing depot nodes are allowed. Components without
            // depot nodes and containing truck-selected customers must connect to
            // the rest of the truck path.
            if (contains_start || contains_end)
            {
                continue;
            }

            std::vector<Node> S;
            for (int v : comp)
            {
                if (v >= 1 && v <= inst_.n && trel[v] > eps)
                {
                    S.push_back(v);
                }
            }

            if (S.empty())
            {
                continue;
            }

            TryAddTruckConnectivityCutsForSet(S, trel, xrel, cuts_added, max_cuts);

            if (cuts_added >= max_cuts)
            {
                return;
            }
        }
    }

    bool MasterCallback::TryAddTruckConnectivityCutsForSet(
        const std::vector<Node> &S,
        const std::vector<double> &trel,
        const std::vector<std::vector<double>> &xrel,
        int &cuts_added,
        int max_cuts)
    {
        if (S.empty() || cuts_added >= max_cuts)
        {
            return false;
        }

        const int N = inst_.NumNodes();
        const double eps = 1e-6;

        std::vector<int> inS(N, 0);
        for (Node i : S)
        {
            inS[i] = 1;
        }

        // Use the most truck-selected customer in S as the RHS representative.
        Node h = S.front();
        for (Node i : S)
        {
            if (trel[i] > trel[h])
            {
                h = i;
            }
        }

        if (trel[h] <= eps)
        {
            return false;
        }

        double out_value = 0.0;
        double in_value = 0.0;

        for (Node i : S)
        {
            for (int j = 0; j < N; ++j)
            {
                if (inS[j])
                    continue;
                if (!IsTruckArcAllowed(i, j))
                    continue;
                out_value += xrel[i][j];
            }
        }

        for (int i = 0; i < N; ++i)
        {
            if (inS[i])
                continue;

            for (Node j : S)
            {
                if (!IsTruckArcAllowed(i, j))
                    continue;
                in_value += xrel[i][j];
            }
        }

        bool added = false;

        if (out_value + eps < trel[h] && cuts_added < max_cuts)
        {
            GRBLinExpr out_expr = 0.0;

            for (Node i : S)
            {
                for (int j = 0; j < N; ++j)
                {
                    if (inS[j])
                        continue;
                    if (!IsTruckArcAllowed(i, j))
                        continue;
                    out_expr += data_.x[i][j];
                }
            }

            addCut(out_expr >= data_.t[h]);
            cuts_added++;
            added = true;

            if (options_.cut_verbose)
            {
                std::cout << "[USERCUT] truck outgoing connectivity"
                          << ", |S|=" << S.size()
                          << ", lhs=" << out_value
                          << ", rhs=t_" << h << "=" << trel[h]
                          << "\n";
            }
        }

        if (in_value + eps < trel[h] && cuts_added < max_cuts)
        {
            GRBLinExpr in_expr = 0.0;

            for (int i = 0; i < N; ++i)
            {
                if (inS[i])
                    continue;

                for (Node j : S)
                {
                    if (!IsTruckArcAllowed(i, j))
                        continue;
                    in_expr += data_.x[i][j];
                }
            }

            addCut(in_expr >= data_.t[h]);
            cuts_added++;
            added = true;

            if (options_.cut_verbose)
            {
                std::cout << "[USERCUT] truck incoming connectivity"
                          << ", |S|=" << S.size()
                          << ", lhs=" << in_value
                          << ", rhs=t_" << h << "=" << trel[h]
                          << "\n";
            }
        }

        return added;
    }

    void MasterCallback::SeparateFractionalDroneCoverCuts(
        const std::vector<std::vector<double>> &arel,
        const std::vector<double> &qrel,
        const std::vector<double> &zKrel,
        int &cuts_added,
        int max_cuts)
    {
        const int K = inst_.n_drones;
        const double eps = 1e-6;

        for (int k = 0; k < K; ++k)
        {
            std::vector<Node> order;

            for (Node i = 1; i <= inst_.n; ++i)
            {
                if (!inst_.IsDroneFeasible(i))
                    continue;
                if (arel[i][k] <= eps)
                    continue;
                order.push_back(i);
            }

            if (order.size() < 2)
            {
                continue;
            }

            // Customers with high fractional assignment and high energy are more
            // likely to form violated conditional energy-cover cuts.
            std::sort(order.begin(), order.end(), [&](Node a, Node b)
                      {
            const double score_a =
                arel[a][k] * (1.0 + static_cast<double>(inst_.energy[a]));
            const double score_b =
                arel[b][k] * (1.0 + static_cast<double>(inst_.energy[b]));

            if (std::abs(score_a - score_b) > 1e-9) {
                return score_a > score_b;
            }
            return a < b; });

            std::vector<Node> H;
            H.reserve(order.size());

            for (Node i : order)
            {
                H.push_back(i);

                if (H.size() < 2)
                {
                    continue;
                }

                TryAddDroneCoverCutsForSet(k, H, arel, qrel[k], zKrel[k],
                                           cuts_added, max_cuts);

                if (cuts_added >= max_cuts)
                {
                    return;
                }
            }
        }
    }

    bool MasterCallback::TryAddDroneCoverCutsForSet(
        int drone_id,
        const std::vector<Node> &H,
        const std::vector<std::vector<double>> &arel,
        double qrel,
        double zKrel,
        int &cuts_added,
        int max_cuts)
    {
        if (H.empty() || cuts_added >= max_cuts)
        {
            return false;
        }

        if (inst_.battery_capacity <= 0)
        {
            return false;
        }

        const double eps = 1e-6;

        int64_t total_energy = 0;
        double total_roundtrip = 0.0;
        double sum_a = 0.0;

        for (Node i : H)
        {
            total_energy += inst_.energy[i];
            total_roundtrip += static_cast<double>(inst_.DroneRoundTripTime(i));
            sum_a += arel[i][drone_id];
        }

        const int64_t cycles =
            (total_energy + inst_.battery_capacity - 1) / inst_.battery_capacity;

        const int64_t required_swaps = std::max<int64_t>(0, cycles - 1);

        bool added = false;

        // Conditional energy-cover cut:
        //
        //   q_k + R(|H| - sum_{i in H} a_ik) >= R,
        //
        // where R = ceil(sum e_i / E) - 1.
        //
        // This is valid for all integer assignments. If all H are assigned to
        // drone k, then q_k >= R. If at least one member is missing, the big-M term
        // relaxes the cut.
        if (required_swaps > 0 && cuts_added < max_cuts)
        {
            const double R = static_cast<double>(required_swaps);
            const double lhs_value = qrel + R * (static_cast<double>(H.size()) - sum_a);

            if (lhs_value + 1e-6 < R)
            {
                GRBLinExpr lhs = data_.q[drone_id];

                for (Node i : H)
                {
                    lhs += R * (1.0 - data_.a[i][drone_id]);
                }

                addCut(lhs >= R);
                cuts_added++;
                added = true;

                if (options_.cut_verbose)
                {
                    std::cout << "[USERCUT] drone energy cover"
                              << ", drone=" << drone_id
                              << ", |H|=" << H.size()
                              << ", lhs=" << lhs_value
                              << ", rhs=" << R
                              << "\n";
                }
            }
        }

        if (cuts_added >= max_cuts)
        {
            return added;
        }

        // Conditional drone workload lower-bound cut:
        //
        //   z_k + M(|H| - sum_{i in H} a_ik)
        //       >= sum r_i + tau_swap * R.
        //
        // This strengthens fractional nodes for subsets that are almost fully
        // assigned to a drone.
        const double rhs =
            total_roundtrip +
            static_cast<double>(inst_.swap_time) * static_cast<double>(required_swaps);

        if (rhs > eps)
        {
            const double M = std::max(1.0, rhs);
            const double lhs_value =
                zKrel + M * (static_cast<double>(H.size()) - sum_a);

            if (lhs_value + 1e-6 < rhs && cuts_added < max_cuts)
            {
                GRBLinExpr lhs = data_.zK[drone_id];

                for (Node i : H)
                {
                    lhs += M * (1.0 - data_.a[i][drone_id]);
                }

                addCut(lhs >= rhs);
                cuts_added++;
                added = true;

                if (options_.cut_verbose)
                {
                    std::cout << "[USERCUT] drone subset workload"
                              << ", drone=" << drone_id
                              << ", |H|=" << H.size()
                              << ", lhs=" << lhs_value
                              << ", rhs=" << rhs
                              << "\n";
                }
            }
        }

        return added;
    }

    void MasterCallback::HandleIntegerSolution()
    {
        const int N = inst_.NumNodes();

        std::vector<int> tbar(N, 0);
        std::vector<std::vector<int>> abar(
            N,
            std::vector<int>(inst_.n_drones, 0));
        std::vector<std::vector<int>> xbar(N, std::vector<int>(N, 0));

        for (Node i = 1; i <= inst_.n; ++i)
        {
            tbar[i] = getSolution(data_.t[i]) > 0.5 ? 1 : 0;

            for (int k = 0; k < inst_.n_drones; ++k)
            {
                abar[i][k] = getSolution(data_.a[i][k]) > 0.5 ? 1 : 0;
            }
        }

        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                if (i == j)
                    continue;
                if (i == inst_.end_depot)
                    continue;
                if (j == inst_.start_depot)
                    continue;

                xbar[i][j] = getSolution(data_.x[i][j]) > 0.5 ? 1 : 0;
            }
        }

        if (SeparateIntegerTruckSubtourCuts(tbar, xbar))
        {
            // In SEC mode, reject this integer solution before invoking any
            // drone subproblem. This keeps the slave from being called on a
            // master solution whose truck route is disconnected.
            return;
        }

        const double master_z = getSolution(data_.z);
        const double truck_value = ComputeTruckValue(xbar);

        if (std::isfinite(best_valid_ub_) &&
            truck_value >= best_valid_ub_ - 1e-6)
        {
            if (options_.verbose)
            {
                std::cout << "\n[REJECT] truck_value >= valid UB"
                          << ", master_z=" << master_z
                          << ", truck=" << truck_value
                          << ", UB=" << best_valid_ub_
                          << "\n";
            }
            return;
        }

        std::vector<std::vector<Node>> per_drone_customers(inst_.n_drones);

        for (Node i = 1; i <= inst_.n; ++i)
        {
            for (int k = 0; k < inst_.n_drones; ++k)
            {
                if (abar[i][k] == 1)
                {
                    per_drone_customers[k].push_back(i);
                }
            }
        }

        if (options_.verbose)
        {
            std::cout << "\n[MIPSOL] master_z=" << master_z
                      << ", truck=" << truck_value
                      << ", UB=" << best_valid_ub_
                      << "\n";
        }

        DroneSchedule schedule;
        schedule.chains.assign(inst_.n_drones, {});
        schedule.swap_before.assign(inst_.n_drones, {});
        schedule.makespan = 0.0;
        schedule.swap_count = 0;

        std::vector<double> drone_values(inst_.n_drones, 0.0);
        std::vector<int> swap_counts(inst_.n_drones, 0);

        bool all_slaves_feasible = true;
        bool unresolved_invalid_candidate = false;
        int unresolved_drone = -1;
        double unresolved_slave_obj = -1.0;
        double unresolved_slave_lb = -1.0;
        double unresolved_master_zk = -1.0;

        for (int k = 0; k < inst_.n_drones; ++k)
        {
            const std::vector<Node> &S = per_drone_customers[k];

            SlaveOptions slave_opts = options_.slave_options;

            // Important: every slave is solved only in the improving region.
            // Therefore the slave objective is constrained by:
            //
            //     z_slave <= current_valid_UB - 1.
            //
            // This is passed to the slave through makespan_cutoff and is also
            // printed in the log for debugging.
            int64_t slave_cutoff = -1;

            if (std::isfinite(best_valid_ub_))
            {
                slave_cutoff =
                    static_cast<int64_t>(std::floor(best_valid_ub_ - 1.0 + 1e-9));

                if (slave_opts.makespan_cutoff >= 0)
                {
                    slave_opts.makespan_cutoff =
                        std::min<int64_t>(slave_opts.makespan_cutoff, slave_cutoff);
                }
                else
                {
                    slave_opts.makespan_cutoff = slave_cutoff;
                }
            }

            PrintSlaveCall(k, S, slave_opts.makespan_cutoff);

            SlaveResult r = slave_.Solve(S, slave_opts);

            PrintSlaveResult(k, S, slave_opts.makespan_cutoff, r);

            if (!r.feasible)
            {
                all_slaves_feasible = false;

                if (r.proven_infeasible && std::isfinite(best_valid_ub_))
                {
                    // The set S cannot be served by one drone under UB-1.
                    // Since drones are identical, forbid this set on every drone.
                    AddBroadcastDroneNoGoodCut(S);
                    AddBroadcastDroneSubsetLowerBoundCut(S, best_valid_ub_);
                }
                else if (r.lower_bound_valid)
                {
                    AddBroadcastDroneSubsetLowerBoundCut(S, static_cast<double>(r.lower_bound));
                }
                else
                {
                    unresolved_invalid_candidate = true;
                    unresolved_drone = k;
                    unresolved_slave_obj = -1.0;
                    unresolved_slave_lb = r.lower_bound_valid ? static_cast<double>(r.lower_bound) : -1.0;
                    unresolved_master_zk = getSolution(data_.zK[k]);
                }

                continue;
            }

            drone_values[k] = static_cast<double>(r.objective);
            schedule.makespan = std::max(schedule.makespan, drone_values[k]);

            if (!r.chains.empty())
            {
                schedule.chains[k] = r.chains.front();
                schedule.swap_before[k] = r.swap_before.front();

                for (int v : schedule.swap_before[k])
                {
                    if (v != 0)
                    {
                        schedule.swap_count++;
                        swap_counts[k]++;
                    }
                }
            }

            const double zK_master = getSolution(data_.zK[k]);

            if (r.optimal)
            {
                // If the slave proves optimality, its objective is a valid lower
                // bound for the same customer subset. Broadcast this cut to all
                // identical drones.
                if (zK_master + 1e-6 < static_cast<double>(r.objective))
                {
                    AddBroadcastDroneSubsetLowerBoundCut(S, static_cast<double>(r.objective));
                }
            }
            else if (r.lower_bound_valid)
            {
                // If the slave is feasible but not optimal, only its lower bound is
                // valid for cutting. Its feasible objective is still a valid
                // original-problem completion and may be used to submit/update UB.
                if (zK_master + 1e-6 < static_cast<double>(r.lower_bound))
                {
                    AddBroadcastDroneSubsetLowerBoundCut(S, static_cast<double>(r.lower_bound));
                }

                if (options_.verbose &&
                    static_cast<double>(r.objective) > zK_master + 1e-6)
                {
                    std::cout << "  [SLAVE-NOTE] feasible but not optimal; "
                              << "do not cut with obj. "
                              << "drone=" << k
                              << ", slave_obj=" << r.objective
                              << ", slave_lb=" << r.lower_bound
                              << ", master_zk=" << zK_master
                              << "\n";
                }
            }
            else
            {
                // Feasible slave without a valid lower bound:
                // - do NOT abort;
                // - do NOT add a z_k >= objective cut;
                // - use the feasible objective only to construct a valid incumbent.
                if (options_.verbose &&
                    static_cast<double>(r.objective) > zK_master + 1e-6)
                {
                    std::cout << "  [SLAVE-NOTE] feasible without proof; "
                              << "use obj only for incumbent submission. "
                              << "drone=" << k
                              << ", slave_obj=" << r.objective
                              << ", master_zk=" << zK_master
                              << "\n";
                }
            }
        }

        if (unresolved_invalid_candidate)
        {
            std::cerr << "\n[ERROR] A slave call did not provide enough proof "
                      << "to verify or cut the master incumbent. Aborting.\n"
                      << "        unresolved_drone=" << unresolved_drone
                      << ", slave_obj=" << unresolved_slave_obj
                      << ", slave_lb=" << unresolved_slave_lb
                      << ", master_zk=" << unresolved_master_zk
                      << ", current_UB=" << best_valid_ub_
                      << "\n"
                      << "        Increase slave_time, use exact CP-SAT, or use MILP slave. "
                      << "For SWAP TIME = 0, v9 returns an exact slave value directly.\n";
            abort();
            return;
        }

        if (!all_slaves_feasible)
        {
            if (options_.verbose)
            {
                std::cout << "[REJECT] at least one slave infeasible/unknown\n";
            }
            return;
        }

        const double accepted_z = std::max(truck_value, schedule.makespan);

        // This is the value submitted to Gurobi's master model.
        //
        // If a feasible slave completion has z_slave > master_z, then accepted_z
        // raises the submitted master objective accordingly. If master_z is already
        // larger, submitted_z keeps the incumbent consistent with the current
        // master objective value.
        //
        // The valid original-problem UB remains accepted_z.
        const double submitted_z = std::max(master_z, accepted_z);

        if (options_.verbose)
        {
            std::cout << "  [SLAVE-SUMMARY] truck=" << truck_value
                      << ", drone_makespan=" << schedule.makespan
                      << ", accepted_z=" << accepted_z
                      << ", submitted_master_z=" << submitted_z
                      << ", master_z=" << master_z
                      << ", current_UB=" << best_valid_ub_
                      << "\n";
        }

        TryAccept(
            tbar,
            abar,
            xbar,
            per_drone_customers,
            schedule,
            drone_values,
            swap_counts,
            truck_value,
            schedule.makespan,
            accepted_z,
            submitted_z);
    }

} // namespace bbcp
